# Atelier Zero Email Modules

This local-only library contains all 94 source modules rebranded to Atelier Zero v7. The original `modules/all/` library is unchanged. Field identifiers are preserved, all modules are editable/non-global, and the four local-only dark drafts reuse their paired light-module fields only because their referenced field sets are identical.

Do not upload or publish these modules until the compliance report, copy claims, links, HubSpot rendering, and final owner review are closed.
